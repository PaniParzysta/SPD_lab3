﻿// spd_lab3.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
using namespace std;

int cmax(int N, int M, int* P, int* X) //funkcja licząca długość wykonywania zadań
{
	int T[100];
	for (int m = 0; m <= M; m++)
	{
		T[m] = 0;
	}
	for (int n = 0; n < N; n++)
	{
		for (int m = 1; m <= M; m++)
		{
			T[m] = max(T[m], T[m - 1]) + P[(m - 1) + X[n] * M];
		}
	}
	return T[M];
}

int NEH(int N, int M, int* P, int* X)
{
	int* W = new int[N];
	for (int c = 0; c < N; c++)	 
	{
		for (int d = 0; d < M; d++)
		{
			W[c] += P[c * M + d];
		}
	}
	for (int b = 0; b < N - 1; b++)		
	{
		for (int a = 0; a < N - 1; a++)
		{
			if (W[a] < W[a + 1])
			{
				swap(W[a], W[a + 1]);
				swap(X[a], X[a + 1]);
			}
		}
	}
	delete[]W;

	for (int n = 0; n < N; n++)		
	{
		int bestP = -1, bestCmax = 999999999;
		for (int p = n; p >= 0; p--)
		{
			int tmp = cmax(n + 1, M, P, X);
			if (bestCmax >= tmp)
			{
				bestCmax = tmp;
				bestP = p;
			}
			if (p)
			{
				swap(X[p], X[p - 1]);
			}
		}
		for (int i = 0; i < bestP; i++)
		{
			swap(X[i], X[i + 1]);
		}
	}
	return cmax(N, M, P, X);
}
int main()
{
	int neh, N, M, P[10000], X[1000];
	string str = "data.", str1, str2;
	ifstream f("data.txt");		
	auto start = chrono::high_resolution_clock::now();

	for (int i = 0; i <= 120; i++)
	{
		
		char tab_str[4];
		snprintf(tab_str, 4, "%03d", i);
		string kolejnosc(tab_str);
		str1 = str + kolejnosc + ":";

		while (str2 != str1)				
			f >> str2;
	
		f >> N >> M;						
		for (int j = 0; j < N * M; j++)		
		{
			f >> P[j];
			for (int j = 0; j < N; j++)
				X[j] = j;
		}

		auto start_pom = chrono::high_resolution_clock::now();
		neh = NEH(N, M, P, X);
		auto koniec_pom = chrono::high_resolution_clock::now();
		auto czas_wyk = chrono::duration_cast<chrono::nanoseconds>(koniec_pom - start_pom);
		cout << str1 << " " << neh << " czas wykonania: " << czas_wyk.count() * 1e-9 << "s" << endl;
	}
	auto koniec = chrono::high_resolution_clock::now();
	auto czas_calk = chrono::duration_cast<chrono::nanoseconds>(koniec - start);
	cout << "Czas całkowiny: " << czas_calk.count() * 1e-9 << "s" << endl;
}